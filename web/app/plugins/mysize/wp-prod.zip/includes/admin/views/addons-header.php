<?php echo $category;?>
<div class="wp-list-table widefat plugin-install">
	<div class="the-list wc_pbp_addon_listing">
	