<?php
/**
 * The admin-specific functionality of the plugin.
 * @link [plugin_url]
 * @package [package]
 * @subpackage [package]/Admin
 * @since [version]
 */
if ( ! defined( 'WPINC' ) ) { die; }

class WooCommerce_Plugin_Boiler_Plate_Admin_Sample_Class {
    
    public function __construct() {
    
    }
}