<?php
/**
 * Summary (no period for file headers)
 *
 * Description. (use period)
 *
 * @link [plugin_url]
 * @package [package]
 * @subpackage [package]/core
 * @since [version]
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }