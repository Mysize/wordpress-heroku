<?php 

/**
 * Plugin Name: Sample Addon 1
 * Plugin URI:
 * Version: 1.0
 * Description: Allows to increase price based on product price.. for easy use.
 * Author: Varun Sridharan
 * Author URI: http://varunsridharan.in
 * Last Update: 2015-06-22 
 * Category: Tools
 */

if ( ! defined( 'PLUGIN_ADDON' ) ) { die; }

class Sample_Addon_1 {
 
}

return new Sample_Addon_1;
?>